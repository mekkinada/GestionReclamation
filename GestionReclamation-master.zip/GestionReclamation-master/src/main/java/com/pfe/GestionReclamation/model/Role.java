package com.pfe.GestionReclamation.model;



public enum Role {
	ELEVE,
	INTERVENANT,ADMIN

}
