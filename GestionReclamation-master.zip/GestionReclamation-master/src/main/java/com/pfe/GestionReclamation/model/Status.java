package com.pfe.GestionReclamation.model;

public enum Status {
    VERIFIE,
    REJETEE,
    EN_COURS,
}
