package com.pfe.GestionReclamation.model;

public enum Specialite {
    INFORMATIQUE,
    ELECTRIQUE,
    MARKETING,
    MECANIQUE,
    AUTRE
}
