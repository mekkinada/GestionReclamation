package com.pfe.GestionReclamation.model;

public enum NiveauScolaire {
    NULL,
    NIVEAU_1,
    NIVEAU_2,
    NIVEAU_3,
    NIVEAU_4,
    NIVEAU_5
}
