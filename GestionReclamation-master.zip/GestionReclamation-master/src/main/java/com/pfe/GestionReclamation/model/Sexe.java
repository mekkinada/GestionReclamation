package com.pfe.GestionReclamation.model;

public enum Sexe {
    MASCULAIN,
    FEMININ
}
