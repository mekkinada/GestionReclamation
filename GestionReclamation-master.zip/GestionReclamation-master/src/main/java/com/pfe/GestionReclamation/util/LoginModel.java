package com.pfe.GestionReclamation.util;

import lombok.*;

@Data
public class LoginModel {
    private String email;
    private String password;
}
